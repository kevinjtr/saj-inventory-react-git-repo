import {combineReducers} from 'redux'

//import products from './products'
//import users from './users'

const rootReducers = combineReducers({
    //users,
    //products
})

export default rootReducers