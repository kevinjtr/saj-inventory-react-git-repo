// import { getConfiguredCache } from 'money-clip'

// export default getConfiguredCache({
//   maxAge: 1000 * 60 * 60,
//   version: 1
// })